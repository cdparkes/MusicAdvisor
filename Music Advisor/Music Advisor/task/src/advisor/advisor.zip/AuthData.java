package advisor;

class AuthData {

    private String code;
    private String accessToken;

    public String getCode() {
        return code;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
